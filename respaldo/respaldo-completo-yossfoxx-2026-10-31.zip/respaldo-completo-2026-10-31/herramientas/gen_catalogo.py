import re, os, json
from PIL import Image as PILImage
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

JSONFILE = os.path.expanduser('~/workspace/staging/juegos.json')
PORT = os.path.expanduser('~/workspace/portadas')
OUT = os.path.expanduser('~/workspace/staging/catalogo.pdf')
W, H = A4
BG = HexColor('#0b1220'); CARD = HexColor('#131c2e'); INK = HexColor('#e8eef4'); MUT = HexColor('#9db2c3'); GOLD = HexColor('#d4af37')

games = []
for g in json.load(open(JSONFILE, encoding='utf-8')):
    num = int(g['id'].replace('game-', ''))
    cover = re.search(r'/(\d+)\.webp$', g['cover']).group(1)
    games.append(dict(num=num, title=g['title'], cap=float(g['capacity']), cover=cover, prem=bool(g.get('premiere'))))
assert len(games) == 155, len(games)

def price(g):
    if g['title'] == 'EA SPORTS FC 27': return 1000
    if g['cap'] <= 1: return 200
    return 300 if g['cap'] <= 3 else 500
def sizestr(cap):
    if cap < 1: return f"{round(cap*1000)} MB"
    return f"{cap:g} GB"

prems = [g for g in games if g['prem']]
prems.sort(key=lambda g: (g['title'] != 'EA SPORTS FC 27', -g['num']))
featured = prems[:12]
regular = prems[12:] + [g for g in games if not g['prem']]
regular.sort(key=lambda g: g['title'].casefold())
pages = [regular[i:i+20] for i in range(0, len(regular), 20)]  # 20/página: 5 filas visibles (antes 32 desbordaban la página)
print('featured:', [g['title'] for g in featured])
print('catalog pages:', [len(p) for p in pages], 'total games:', len(games), 'total GB:', round(sum(g['cap'] for g in games), 2))

c = canvas.Canvas(OUT, pagesize=A4)
c.setTitle('Catálogo YossFoxx PS4')

def header(y, subtitle):
    c.setFillColor(HexColor('#1a1030')); c.rect(0, H-58, W, 58, stroke=0, fill=1)
    c.setFillColor(GOLD); c.rect(0, H-61, W, 3, stroke=0, fill=1)
    c.setFillColor(INK); c.setFont('Helvetica-Bold', 20); c.drawString(36, H-34, 'YossFoxx — Mis Juegos PS4')
    c.setFillColor(MUT); c.setFont('Helvetica', 10); c.drawString(36, H-50, subtitle)

def footer(pageno):
    c.setFillColor(MUT); c.setFont('Helvetica', 9)
    c.drawString(36, 28, '¡CADA 4 JUEGOS, 1 GRATIS!  ·  Pedidos por WhatsApp: 52390321')
    c.drawRightString(W-36, 28, f'Página {pageno}')

def card(x, y, w, h, g, thumbsize):
    c.setFillColor(CARD); c.roundRect(x, y, w, h, 6, stroke=0, fill=1)
    p = os.path.join(PORT, g['cover'] + '.webp')
    try:
        im = PILImage.open(p).convert('RGB')
        if im.width > 240:
            im = im.resize((240, int(im.height*240/im.width)), PILImage.LANCZOS)
        iw, ih = im.size
        import tempfile
        tf = tempfile.NamedTemporaryFile(suffix='.jpg', delete=False)
        im.save(tf.name, 'JPEG', quality=72)
        im = tf.name
        scale = min(thumbsize[0]/iw, thumbsize[1]/ih)
        nw, nh = iw*scale, ih*scale
        c.drawImage(im, x+(w-nw)/2, y+h-thumbsize[1]-4+(thumbsize[1]-nh)/2, width=nw, height=nh, preserveAspectRatio=True, mask='auto')
    except Exception as e:
        c.setFillColor(MUT); c.setFont('Helvetica', 7); c.drawCentredString(x+w/2, y+h/2, 'sin portada')
    c.setFillColor(INK); c.setFont('Helvetica-Bold', 8)
    title = g['title']
    if len(title) > 26: title = title[:25] + '…'
    c.drawCentredString(x+w/2, y+26, title)
    c.setFillColor(MUT); c.setFont('Helvetica', 8)
    c.drawCentredString(x+w/2, y+14, f"{sizestr(g['cap'])}  ·  {price(g)} CUP")

# Page 1: ESTRENOS
header(H-58, 'ESTRENOS — Los 12 más recientes (EA SPORTS FC 27 primero)')
mx, gap = 36, 12
cw = (W-2*mx-3*gap)/4
ch = 168
y0 = H-58-24-ch
for i, g in enumerate(featured):
    col, row = i % 4, i // 4
    card(mx+col*(cw+gap), y0-row*(ch+gap), cw, ch, g, (cw-8, 118))
footer(1); c.showPage()
# Catalog pages
for pi, pg in enumerate(pages):
    header(H-58, f'Catálogo — Página {pi+1} de {len(pages)} ({len(regular)} juegos)')
    cw2 = (W-2*mx-3*gap)/4
    ch2 = 118
    y0 = H-58-24-ch2
    for i, g in enumerate(pg):
        col, row = i % 4, i // 4
        card(mx+col*(cw2+gap), y0-row*(ch2+gap), cw2, ch2, g, (cw2-8, 72))
    footer(pi+2); c.showPage()
c.save()
print('PDF ok:', OUT, os.path.getsize(OUT), 'bytes')
