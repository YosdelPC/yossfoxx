# Maintain the PS4 game store

## Apply the catalog update

- Read the catalog file the user sends and treat it as the source of truth for game names, sizes in GB and the Estrenos column that marks new releases.

- Apply the store pricing tiers: games of 1 GB or less cost 200 CUP, games of 3 GB or less cost 300 CUP, EA SPORTS FC 27 costs 1000 CUP and every other game costs 500 CUP (the 200 CUP tier was added by the user on 2026-10-28; before that it was 3 GB or less for 300 CUP).

- Keep each cover to the game name, its capacity in GB and its price. Never print a fixed price on a cover when the pricing tiers decide it.

## Lay out the ESTRENOS section

- Place ESTRENOS first in a muted blue gray panel and keep its game titles in dark text that stays readable against the panel.

- Order the newest release first. Show six covers per row on desktop and three per row on phones so the section reads as distinct from the regular catalog.

- Label the cover buttons Pedir and Trailer. When a game is added, change its button to Agregado, show the notice that it is already in the cart and play the user's cash register sound.

- Every game card should have a Trailer button: if no official trailer can be found for a game, use a gameplay video of that game for the Trailer button instead of leaving the card without one (user rule set on 2026-10-21).

- Covers live as separate files in the repo's portadas folder (WebP, 500x700, at most 60 KB each) and the page loads them from the GitHub Pages URL. Each cover file is named with the game's sequential 5-digit ID: 00001.webp, 00002.webp, and so on. One number per game; every newly added game takes the next number at the end, and numbers are never reused or reshuffled (user rule set on 2026-10-22).

- ESTRENOS shows only the 12 most recent releases, with FC 27 pinned first; older releases move into the main catalog (user rule set on 2026-10-22).

## Keep the uniform cover template

- Every cover uses the same template (user-approved on 2026-10-22): flat front official art filling the whole card, no 3D case renders, no spine, no plastic frame, no white margins, center-cropped to exactly 500x700.

- Every cover carries the same watermark strip inside the image at the bottom: a semi-transparent navy band (about 14 percent of the height) with a thin gold line on top, YossFoxx in white bold and his number 52390321 in gold below it.

- Process covers with the portadas audit script in the workspace: a replacement source placed in the portadas-new folder overrides the current cover in the portadas folder; the script auto-trims uniform white and black borders from replacement sources, crops, watermarks and writes WebP at most 60 KB into the portadas-final folder. Upload the finals into portadas under the same file names (batches of 32) and verify live by comparing served byte sizes. GitHub Pages may keep serving the old cover for a few minutes after the commit.

- If no flat cover exists for a game, fall back in this order: the game's flat key art or digital store art; a front-facing case render cropped inward past its plastic frame; and only when no official cover exists at all, full-bleed art from the game itself (as done for Street Food).

- When the official art is square (PlayStation Store main art is 1024x1024) and a center crop to portrait would cut the title, do not crop the title: fit the full art on top of the 500x700 card and extend its lower texture downward to fill the rest (blurred slightly), then apply the watermark. Used for Sniper Elite 5, Machinarium and Call of Duty - MW3 (Modern Warfare III) on 2026-10-28.

## Wire the cart and the WhatsApp order

- Number each cart entry, show each game's size in GB and show the cart total in GB.

- Open the user's WhatsApp with his chosen greeting followed by the numbered games. Read the greeting and his order number from MEMORY.md and never invent either.

- Tell him plainly that the page opens WhatsApp with the message written and that he presses send himself.

- Load covers lazily so the page works on his slow connection.

- Repaint both cart counters from the saved cart after the page finishes loading, so the top counter and the bottom bar counter agree from the first moment.

- Keep the button to clear the cart inside the cart panel below the WhatsApp send button. The first tap asks for confirmation and only a second tap within 3 seconds clears the list, the saved cart and both counters to zero. Keep the button disabled while the cart is empty.

## Publish and hand over

- After every change he will review, publish the artifact and confirm the public link serves the new version before telling him to open it. Never leave him on a stale link.

- When he edits a local copy himself, explain that his file and the public link are separate, and offer to carry his change into the published page.

## Deploy the GitHub Pages copy

- Deploy the GitHub Pages copy at https://github.com/YosdelPC/yossfoxx with the same content as the published artifact, and keep the live filename stable. The redirect in index.html points at one canonical name, so a rename takes the page down until the redirect is fixed.

- When the automatic upload path refuses the file, say so plainly before trying a fallback. The store file is about 14 MB and the automatic GitHub connection refuses large files, so state the fallback route first and re-verify the redirect after it.

- Always upload the store file under its final live name (JuegosPS4.html, the simple name the user chose on 2026-10-22; live URL https://yosdelpc.github.io/yossfoxx/JuegosPS4.html, with index.html redirecting to it) so the classic upload page replaces it in a single commit. Do not upload it under a different name and rename afterwards: the web editor cannot load a 14 MB file and github.dev fails to commit a 14 MB content change (both verified on 2026-10-21; the same-name upload worked).

- Never delete the live file before its replacement is committed and verified. For the store page, the same-name upload is the commit, so verify the served page before touching anything else. A delete that runs before the replacement lands leaves the store offline, as happened on 2026-10-22.

- Upload large asset sets in bounded batches and confirm each batch is committed before starting the next. Do not put all files in one upload, and when an upload stalls, resume with the next missing batch instead of restarting everything. This covers the 144 covers in portadas on 2026-10-22.

- When the web editor cannot commit or rename a heavy file, shrink or split the file first and then replace it under the same live name. Do not use delete-then-rename as a workaround for the size limit. Same-name replacement keeps the redirect and cache behavior predictable.

- After every upload, verify the redirect chain end to end: the root URL serves the page, the index.html redirect lands on the exact uploaded filename, and the served bytes match the source before telling him it is live.

- Verify a functional change in a fresh tab with a forced reload after allowing time for GitHub Pages to publish the new version. A check that fails within about a minute of the upload may be testing the cached old version, so recheck before applying another fix or reporting the fix as failed.

- Say plainly when a first live check failed only because it tested a cached old version, and name the recheck that passed.

- Tell him honestly when a first load will feel slow. A renamed or new filename has a cold distribution cache that normalizes on its own after a few visits, so ask him to retry later instead of re-uploading the same content.

## Available connectors

- Use muse.connector_search to find other connectors and muse.skill_search to find related skills.

- If nothing here fits, look on the web for a maintained API or MCP server and set it up with Custom Connectors and MCPs, or build a custom connector.

## Alternatives for better results

- When he asks for the promo image for his WhatsApp status, generate it vertical 9:16 with his real number, the real store link and an attention line such as LOS MEJORES PRECIOS instead of printing prices, and read the rendered link character by character before sending it.

## Catalog data lives in juegos.json (2026-10-31)

- The game list is NOT in the HTML anymore. Source of truth: `doc/juegos.json` in GitHub (and `assets/doc/juegos.json` in the Muse copy), one JSON object per line, fields id/title/capacity/cover/trailer/premiere. Adding a game = one line there, plus its verified cover in `imagenes/portadas/`, then regenerate the PDF.
- The page fetches `doc/juegos.json` on load (GitHub) / `assets/doc/juegos.json` (Muse copy), shows a loading state, shows an error with retry on failure, and restores the saved cart only after the list loads. Never restore/validate the saved cart against an empty list.
- The PDF generator (`gen_catalogo.py`) reads `~/workspace/staging/juegos.json`, not the HTML. It sorts the catalog A–Z (ESTRENOS stays newest-first, FC 27 pinned). Regenerate and re-upload the PDF on every catalog change.
- CSS and JS stay INSIDE JuegosPS4.html (Yosdel's decision 2026-10-31: fewer files, fewer cross-copy path and stale-cache errors, one atomic deploy per copy). Do not split them into separate files without him asking again.
